let planksX = [0,150,300,450,600,750];  //tan rectangles!
let ghostX = [];
let ghostY = [];
let visible = true;

function setup() {
  createCanvas(900, 600);
  colorMode(RGB);
  
  for(i=0; i<8; i++){
    ghostX[i] = random(10,890); //X position of the ghosts!
    ghostY[i] = random(10,590);  //Y position of the ghosts!
  }
  console.log("GhostX",ghostX);  //shows the initial ghostX array
  console.log("GhostY", ghostY); //shows the initial ghostY array
}

function draw() {
  background(100,0,250);
  
  fill(200,150,250);
  stroke(0,0,0);
  strokeWeight(3);
  rect(300,0,300,600); //The door!
  circle(550,230,50)
  
  noStroke();
  fill(250,150,100);
  stroke(0,0,0);
  strokeWeight(2);
  rect(planksX[0],400,150,200);
  rect(planksX[1],400,150,200);
  rect(planksX[2],400,150,200);
  rect(planksX[3],400,150,200);
  rect(planksX[4],400,150,200);
  rect(planksX[5],400,150,200);
  
  for(i=0; i< ghostX.length-1; i++){
    fill(255,255,255);
    noStroke();
    square(ghostX[i],ghostY[i],50);
    triangle(ghostX[i]+25,ghostY[i]+80,ghostX[i]+50,ghostY[i]+49,ghostX[i]+0,ghostY[i]+49);
    stroke(255,255,255);
    strokeWeight(5);
    line(ghostX[i]-20,ghostY[i]+30,ghostX[i]+70,ghostY[i]+30);
    noStroke();
    fill(0,0,0);
    square(ghostX[i]+2,ghostY[i]+10,10); //Ghost faces!
    square(ghostX[i]+38,ghostY[i]+10,10);  //Ghost faces!
    rect(ghostX[i]+20,ghostY[i]+20,15,40);  //Ghost faces!
    
    ghostX[i] += random(1,-1);
    ghostY[i] += random(1,-1);
  }
  start();
  ghostX[8] = mouseX;
  ghostY[8] = mouseY;
  
  stroke(255,255,255);
  strokeWeight(1);
  fill(250,100,250);
  triangle(ghostX[8],ghostY[8],ghostX[8]-15,ghostY[8]-15,ghostX[8]-15,ghostY[8]+15); //The Candy!
  triangle(ghostX[8],ghostY[8],ghostX[8]+15,ghostY[8]-15,ghostX[8]+15,ghostY[8]+15); //The Candy!
  ellipse(ghostX[8],ghostY[8],20,15); //The Candy!
  
  d = dist(ghostX[0],ghostY[0],mouseX,mouseY);
  mousePressed();
}

function start(){
  if (visible){
    stroke(0,0,0);
    fill(255,255,255);
    textSize(50);
    text("Find the Ghost who wants Candy!", 80,300);
  }
}

function mouseClicked(){
  visible = false
}

function mousePressed(){
  if (d < 30){
    console.log("TrickorTreat!");
    stroke(0,0,0);
    fill(255,255,255);
    textSize(50);
    text("You found the Ghost!", 200,300);
  }
}