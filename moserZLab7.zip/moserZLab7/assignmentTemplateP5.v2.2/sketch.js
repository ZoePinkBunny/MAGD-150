let allMoney = ["$0 :(","Penny","Nickle","Dime","Quarter","1 Dollar","$20","$100","$50","$1 Million"];
let myMoney = [];
let rectX = [];
let rectY = [];
let rectXY = [];

function setup() {
  createCanvas(600, 500);
  background(220);
  textSize(15);
  colorMode(RGB);
  
   for(i=0; i<5; i++){
    fill(10,190,0);
    rectX[i] = random(300,width-100)
    rectY[i] = random(100,height-50)
    rect(rectX[i], rectY[i],70,40)
    rectXY.push(rectX[i]);
    rectXY.push(rectY[i]);

    let num = Math.floor(random(0,allMoney.length));
    console.log("allMoney #"+num);  //what number was picked
    myMoney.push(allMoney[num]);  //adding money to myMoney
    allMoney.splice(num,1);  //removing money from allMoney
    fill(0,0,0);
    text(myMoney[i],rectX[i]+2,rectY[i]+25);
  }
  rand = random(myMoney.concat(allMoney));
  console.log("XY Values:",rectXY);  //combining X and Y values from rectX and rectY. Pattern is XYXY
  text("Array 1: "+allMoney,20,50);  //remaining money in allMoney
  text("Array 2: "+myMoney,20,100);  // myMoney selections from allMoney
  text("Random 1: "+random(allMoney),20,150);  //random value from Array 1
  text("Random 2: "+random(myMoney),20,200);  //random value from Array 2
  text("Random 1 & 2: "+rand,20,250);
}