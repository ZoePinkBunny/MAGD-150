let gnomeImage;
let snowfall;
let snowBG;
//All images were made by me!

let snowfallY1 = -2000
let snowfallY2 = -3600
let widthR;
let heightR;

function preload(){
  gnomeImage = loadImage ('/assets/Gnome.png');
  snowfall = loadImage ('/assets/Snow.png');
  snowBG = loadImage ('/assets/SnowBG.png');
}

function setup() {
  createCanvas(700, 860);
  angleMode(DEGREES);

  widthR = random(500,width);
  heightR = random(200,height-500);
  console.log("widthR: ",widthR,"heightR: ",heightR);
}

function draw() {
  scale(0.5,0.5);
  image(snowBG,0,0);
  image(gnomeImage,mouseX,mouseY,600,800);

  rotate(-10);
  textSize(150);
  textFont('Gotham');
  strokeWeight(10)
  stroke(210,0,0);
  fill(0,210,0);
  text("Happy Holidays!",30,350);

  rotate(20);
  textSize(50);
  strokeWeight(3);
  stroke(255,255,255);
  fill(210,0,0);
  text("Fill the Holidays with",widthR,heightR);
  text("Sugar Gnome Delights!",widthR,heightR+50);

  rotate(-10);
  scale(1.5,1.5);
  image(snowfall,-500,snowfallY1);
  image(snowfall,-500,snowfallY2);
  snowfallY1+=1 //falling snow!
  snowfallY2+=1  //allows for seamless rotation of snow falling!

  
  if (snowfallY1 > 900){
    snowfallY1 = -2000
    console.log("snowfall1!");
  }
  if (snowfallY2 > 900){
    snowfallY2 = -2000
    console.log("snowfall2!");
  }
}